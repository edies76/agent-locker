module.exports=[2269,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cli_page_actions_0xca-ij.js.map