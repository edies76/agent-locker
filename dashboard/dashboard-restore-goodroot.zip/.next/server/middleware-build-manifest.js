globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/xSIfI2LWbh6XxZDAiO8Kx/_buildManifest.js",
    "static/xSIfI2LWbh6XxZDAiO8Kx/_ssgManifest.js",
    "static/xSIfI2LWbh6XxZDAiO8Kx/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/00d.p9zz2jh0..js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0h4bq73pogmtb.js",
    "static/chunks/062hzijh369a_.js",
    "static/chunks/turbopack-1321nm4qlt~_1.js"
  ]
};
