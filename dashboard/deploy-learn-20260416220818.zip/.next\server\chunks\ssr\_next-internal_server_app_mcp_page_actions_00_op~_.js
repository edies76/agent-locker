module.exports=[99155,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mcp_page_actions_00_op~_.js.map