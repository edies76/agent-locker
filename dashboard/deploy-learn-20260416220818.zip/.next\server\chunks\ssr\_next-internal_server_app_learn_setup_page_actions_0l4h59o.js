module.exports=[38213,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_learn_setup_page_actions_0l4h59o.js.map