module.exports=[13363,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_mcp_%5BserverName%5D_page_actions_0luyvnl.js.map