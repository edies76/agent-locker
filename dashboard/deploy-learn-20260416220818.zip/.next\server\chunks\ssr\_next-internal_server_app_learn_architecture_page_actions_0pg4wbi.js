module.exports=[97205,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_learn_architecture_page_actions_0pg4wbi.js.map