var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/agent-lock-ai/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0lg5lgg._.js")
R.c("server/chunks/_next-internal_server_app_api_agent-lock-ai_route_actions_0k3stly.js")
R.m(47676)
module.exports=R.m(47676).exports
