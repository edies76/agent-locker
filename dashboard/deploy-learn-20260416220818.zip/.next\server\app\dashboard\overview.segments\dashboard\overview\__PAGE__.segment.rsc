1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/0.r1t~n650_xm.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"gKAyzY9BumnZZqmIcno9m"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/overview;307;"}
