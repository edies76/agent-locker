module.exports=[16635,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mcp_%5BserverName%5D_page_actions_0n24bsg.js.map