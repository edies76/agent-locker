module.exports=[26733,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_plugin_page_actions_10skdjp.js.map