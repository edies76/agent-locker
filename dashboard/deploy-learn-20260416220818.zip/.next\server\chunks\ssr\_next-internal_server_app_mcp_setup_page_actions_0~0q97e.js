module.exports=[11248,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mcp_setup_page_actions_0~0q97e.js.map