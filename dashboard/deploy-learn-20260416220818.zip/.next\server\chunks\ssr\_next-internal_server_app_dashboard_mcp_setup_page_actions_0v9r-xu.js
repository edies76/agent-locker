module.exports=[73168,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_mcp_setup_page_actions_0v9r-xu.js.map