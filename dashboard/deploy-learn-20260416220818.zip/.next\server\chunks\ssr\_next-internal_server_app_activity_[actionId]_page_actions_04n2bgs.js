module.exports=[1756,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_activity_%5BactionId%5D_page_actions_04n2bgs.js.map