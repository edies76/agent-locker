1:"$Sreact.fragment"
2:I[82437,["/_next/static/chunks/0.r1t~n650_xm.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/131ziwonajl3w.js"],"default"]
3:I[84477,["/_next/static/chunks/0.r1t~n650_xm.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/131ziwonajl3w.js"],"default"]
4:I[39756,["/_next/static/chunks/0.r1t~n650_xm.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
5:I[37457,["/_next/static/chunks/0.r1t~n650_xm.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/131ziwonajl3w.js","async":true}]],[["$","$L2",null,{}],["$","main",null,{"className":"min-h-screen transition-all duration-200 md:ml-[15.4rem]","children":["$","div",null,{"className":"app-shell-container px-4 pb-6 pt-16 md:p-6 max-w-screen-xl mx-auto animate-fade-in","children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]}]}]}]]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"gKAyzY9BumnZZqmIcno9m"}
