module.exports=[9220,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_about_page_actions_0hje15i.js.map