module.exports=[87516,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_scopes_page_actions_0dn90mx.js.map