module.exports=[72308,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_scopes_%5Bprovider%5D_page_actions_0xr4on7.js.map