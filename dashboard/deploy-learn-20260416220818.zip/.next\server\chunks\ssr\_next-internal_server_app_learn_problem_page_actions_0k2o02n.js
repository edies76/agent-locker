module.exports=[84378,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_learn_problem_page_actions_0k2o02n.js.map