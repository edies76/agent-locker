module.exports=[3847,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_plugin_page_actions_0r.1tsx.js.map